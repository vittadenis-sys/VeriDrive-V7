# VeriDrive V7

MVP Next.js + Supabase + Stripe

## Deploy
1. npm install
2. Configura .env
3. Esegui schema SQL
4. npm run dev
