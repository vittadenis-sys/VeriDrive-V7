// gallery placeholder
