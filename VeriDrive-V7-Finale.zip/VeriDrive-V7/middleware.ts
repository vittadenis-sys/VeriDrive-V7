import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
export function middleware(req:NextRequest){return NextResponse.next();}
export const config={matcher:["/cliente/:path*","/officina/:path*","/admin/:path*"]};