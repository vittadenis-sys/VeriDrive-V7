// calendar engine placeholder
