// email module placeholder
