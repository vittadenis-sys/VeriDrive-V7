// auth module placeholder
